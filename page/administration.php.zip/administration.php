<?php
//CONNEXION A LA BASE DE DONNEE
    $bdd = new PDO( 'mysql:host=localhost;dbname=articles', 'root', 'root');
    
    $mode_edition = 0;
    //traitement de la modification
    //empty verifie qu'il y a bien quelque chose
    //htmlspecialchars securise
    if(isset($_GET['edit']) AND !empty($_GET['edit'])){
        $mode_edition = 1;
        $edit_id = htmlspecialchars($_GET['edit']);
        $edit_article = $bdd->prepare('SELECT * FROM articles WHERE id = ?');
        $edit_article->execute(array($edit_id));
        
        //verifie que l'article existe bien
        if($edit_article->rowCount() == 1){
            //recuperation de l'article
            $edit_article = $edit_article->fetch();
        }else{
            // \ permet de prendre l'appostrophe en string
            die('Erreur: \'article concerné n\'existe pas');
        }
    }else{
        
    }

    //recuperation donnée article
    if(isset($_POST['article_titre'], $_POST['article_contenu'])){
        if(!empty($_POST['article_titre']) AND !empty($_POST['article_contenu'])){
            $article_titre = htmlspecialchars($_POST['article_titre']);
            $article_contenu = htmlspecialchars($_POST['article_contenu']);
            
            if($mode_edition == 0){
                
                var_dump($_FILES);
                //Pour se fier que ou jpg (refuser les png etc..)
                var_dump(exif_imagetype($_FILES['miniature']['tmp_name']));
                
                
                //insertion des données dans la table article
                // NOW récupère automatiquement la date actuelle
                $ins = $bdd->prepare('INSERT INTO articles (titre, contenu, date_time_publication) VALUES (?, ?, NOW())');
                $ins->execute(array($article_titre, $article_contenu));
                //recuperation du derniere id
                $lastid = $bdd->lastInsertId();
                
                
                //Pas obligatoire la miniature
                if(isset($_FILES['miniature']) AND !empty($_FILES['miniature']['name'])) {
                //tmp_name nous retoune un 2 ce qui correspond a jpg (regarder tableau image type)
                    if(exif_imagetype($_FILES['miniature']['tmp_name']) == 2) {
                    $chemin = 'miniatures/'.$lastid.'.jpg';
                    //deplacer un fichier télécharger
                    move_uploaded_file($_FILES['miniature']['tmp_name'], $chemin);
                } else {
                    $message = 'Votre image doit être au format jpg';
                    }
                }
                $message = 'Votre article a bien été posté';
                
            }else{
                //mise a jour de donnée dans la bdd
                $update = $bdd->prepare('UPDATE articles SET titre = ?, contenu = ?, date_time_edition = NOW() WHERE id = ?');
                $update->execute(array($article_titre, $article_contenu, $edit_id));
                //redirection direct vers l'article
                // ATTENTION !! a ne pas mettre d'espace apres Location
                header('Location: http://localhost:8888/PHP-git/PHP-TeamSpaceCat/page/blog_detail.php?id='.$edit_id);
                $message = 'votre article a bien été mise a jour';
            }
        }else{
            $message = 'Veuillez remplir tous les champs';
        }
    }
?>


<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Redaction / edition</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
    <!-- le enctype permet de ne pas envoyer que du texte -->
  <form method="POST" enctype="multipart/form-data">
      <input type="text" name="article_titre" placeholder="titre"<?php if($mode_edition == 1){ ?>value="<?= $edit_article['titre'] ?>"<?php } ?>/>
      <textarea name="article_contenu" placeholder="conetnue de l'article"><?php if($mode_edition == 1){ ?><?= $edit_article['contenu'] ?><?php } ?></textarea>
      <?php if($mode_edition == 0){ ?>
          <input type="file" name="miniature" />
      <?php } ?>
      <input type="submit" value="envoyer l'article" />
  </form>
  <br>
  <?php if(isset($message)){echo $message;} ?>
</body>
</html>